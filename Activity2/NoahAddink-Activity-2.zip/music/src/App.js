import React from 'react';
import ReactDOM from 'react-dom/client';
import Card from './Card';

ReactDOM.render(<App />, document.querySelector("#root"));