import axios from "axios";

export default axios.create({
    baseURL: 'https://music-app-six-plum.vercel.app/api'

});