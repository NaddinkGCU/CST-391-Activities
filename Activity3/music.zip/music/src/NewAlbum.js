import React from 'react';

const NewAlbum = () => {
    return <div>This is a New Album Form</div>;
};

export default NewAlbum;