import React from 'react';

const AboutThisSite = () =>
{
    return (
        <div>
            <h1>About our company</h1>
            <p>We specialize in making great products and services</p>
        </div>
    );
}

export default AboutThisSite;