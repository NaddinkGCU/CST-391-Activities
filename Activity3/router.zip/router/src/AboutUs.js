import react from "react";

const AboutThisSite = () => {
    return (
        <div>
            <h1>About our company</h1>
            <p>We're super cool and have lots of great products here.</p>
        </div>
    )
}

export default AboutThisSite;