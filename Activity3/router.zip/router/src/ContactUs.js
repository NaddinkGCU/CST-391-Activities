import react from "react";

const ContactUs = () => {
    return (
        <div>
            <h2>Company HQ</h2>
            <p>123 Place</p>
            <p>Gilbert, Arizona</p>
            <p>(123)-456-7890</p>
        </div>
    )
}

export default ContactUs;